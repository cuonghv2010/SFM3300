#ifndef STM8_H
#define STM8_H

#include "stm8s.h"

#endif /* STM8_H */
